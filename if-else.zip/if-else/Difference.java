import java.util.*;
public class Difference{
   public static void main(String[] args){
      Scanner sc=new Scanner(System.in);
      System.out.println("enter a number 1");
      int a=sc.nextInt();
      System.out.println("enter a number 2");
      int b=sc.nextInt();
      if(a>b){
              int x=a-b;
              System.out.println("difference of a and b is"+x);
      
     }
  } 
}