import java.util.*;
public class calculator{
   public static void main(String[] args){
      Scanner sc=new Scanner(System.in);
      System.out.print("enter your expression:");
      int a=sc.nextInt();
      char d=sc.next().charAt(0);
      int b=sc.nextInt();
      switch(d){
         case '+':System.out.print(" sum of " +a+" " +d+ " "+b+" = "+(a+b));
                  break;
         case '-':System.out.print(" subtraction of " +a+" " +d+ " "+b+" = "+(a-b));
                  break;
         case '*':System.out.print(" multiplication of " +a+" " +d+ " "+b+" = "+(a*b));
                  break;
         case '/':System.out.print(" division of "+a+" " +d+ " "+b+" = "+(a/b));
                  break;
         default:System.out.print("error");
      }
   
   }
}