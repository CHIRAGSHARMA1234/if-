import java.util.*;
public class Couple{
   public static void main(String[] args){
       Scanner sc=new Scanner(System.in);
       System.out.println("How many guest");
       int a=sc.nextInt();
       if(a%2==0){
                  System.out.println("all in pair");
          }
             else{
                   System.out.println(" not in pair");
             }
       
      }
   
   }