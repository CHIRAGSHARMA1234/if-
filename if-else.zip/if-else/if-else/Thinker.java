import java.util.*;
public class Thinker
{
   public static void main(String[] args){
      Scanner sc=new Scanner(System.in);
      int a=sc.nextInt();
      if(a%2==0){
           if(a%3==0){
                   System.out.println("coding thinker");
           }
           else{
              System.out.println("coding");

           }
      }
          
          
       if(a%3==0){
              System.out.println("thinker");
       
   
       }

      }
   
   }
   