import java.util.*;
public class Add

{
   public static void main(String [] args){
      Scanner sc=new Scanner (System.in);
      int n=sc.nextInt();
      int a=n%10;
          a=n/10;
      int b=n%10;
          b=n/10;
      int c=n%10;
          c=n/10;
      int d=n%10;
          d=n/10;
       System.out.print("add the number"+(a+b+c+d));

 
 
 
   }
   
}